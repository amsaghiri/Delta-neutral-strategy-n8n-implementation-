Example (truncated):

<b>DSFAB — Insight (Fresh-Only + Auto-Scanner)</b>
Workflow: Smart_Wallet_Process_3_base_version_15_long_report+order_detail_time
Time: 2025-08-17T02:03:00.000Z
Fresh universe: 12/20 (cadence≈60m, window=90m)

🔎 <b>Base</b>  | cap=$200 | fee=0.04% | slip=0.05% | borrow=0.02%/day | LTV=60% | min=0.05%/day
✅ <u>Profitable (candidates)</u>
• <b>ETH</b> | 0.120% | estDaily=$0.32 | age=21.0m | remain≈ 39m | LOW | Short perp (KR) + Long spot (CB)
…

🧭 <b>Auto-Scanner (best combos)</b>
• <b>#1</b> BTC | edge≈ 0.09%/day | estDaily=$0.44 | notional $480 | remain≈ 38m | VALID UNTIL: 2025-08-17T02:59:00Z | Short perp (KR) + Long spot (CB)
