# Disclaimer

This repository is a **research/education** project. It is **not financial advice**. 
Using the included workflow can result in financial loss. You are solely responsible 
for compliance with your local regulations, exchange terms of service, and tax reporting.

Data sources used by the workflow (e.g., Coinbase Exchange API, Kraken Futures API, Google Sheets, Telegram) 
have their own **rate limits** and **terms**. Check and respect them.
