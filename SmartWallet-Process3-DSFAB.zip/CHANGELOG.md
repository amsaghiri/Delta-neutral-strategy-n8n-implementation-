# Changelog

## 2025-08-17
- Initial public release of **DSFAB Process 3** workflow (long report + order detail time).
- Includes README, LICENSE (MIT), DISCLAIMER, SECURITY, CONTRIBUTING, issue templates, and sample outputs.

