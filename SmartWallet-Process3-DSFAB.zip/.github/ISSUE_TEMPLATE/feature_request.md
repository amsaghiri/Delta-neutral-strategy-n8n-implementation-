name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
assignees: ''

---

**Describe the feature**
What problem does this solve?

**Proposed solution**

**Alternatives considered**

**Additional context**
